import { LightningElement } from 'lwc';

export default class Learning extends LightningElement {}

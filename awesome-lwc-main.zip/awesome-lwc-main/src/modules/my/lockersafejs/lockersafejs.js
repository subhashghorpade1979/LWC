import { LightningElement } from 'lwc';

export default class LockerSafeJs extends LightningElement {}
